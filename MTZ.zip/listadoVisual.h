#ifndef LISTADOVISUAL_H_INCLUDED
#define LISTADOVISUAL_H_INCLUDED
#include "clsPersona.h"

void dibujarTablaClientesHeader();
void dibujarTablaClientesRow(Persona reg, int y);
void dibujarFichaCliente(Persona reg);

#endif // LISTADOVISUAL_H_INCLUDED
