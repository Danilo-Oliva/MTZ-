#ifndef MENUGESTIONCLIENTE_H_INCLUDED
#define MENUGESTIONCLIENTE_H_INCLUDED
#include"clsArchivoCliente.h"
#include"clsPersona.h"

void menuClientes();
void ingresarNuevoCliente();
void EliminarClientePermanente();
void buscarCliente();
void menuListarClientes();

#endif // MENUGESTIONCLIENTE_H_INCLUDED
