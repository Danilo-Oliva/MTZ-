#include <iostream>
#include "clsArchivoCliente.h"
#include "clsArchivoActividad.h"
#include "clsArchivoInscripcion.h"
#include "clsPersona.h"
#include "clsActividad.h"
#include "clsInscripcionActividad.h"
#include "menuModificarActividad.h"
#include "menuModificarCliente.h"
#include "menuGestionCliente.h"
#include "menuGestionActividades.h"
#include "rlutil.h"
#include "menusVisual.h"
#include "menuGestionCliente.h"
#include "menuGestionActividades.h"
#include "menuGestionInscripciones.h"

using namespace std;


///ACTIVIDAD
void menuActividades()
{
    ArchivoActividad arch("actividad.dat");
    Actividad act;
    int opcion, y = 0;

        system("cls");
    do
    {
        opcion = -1;

        mostrarMenuActividades(opcion, y);

        switch (opcion)
        {
        case 1:
            ingresarNuevaActividad();
            break;

        case 2:
            menuModificarActividad();
            break;

        case 3:
            menuListarActividades();
            break;
        }
    }
    while (opcion != 0);
        system("cls");
}
///MENU INSCRIPCIONES
void menuInscripciones() {
    int opcion, y = 0;
        system("cls");
    do {
        opcion = -1;

        mostrarMenuInscripciones(opcion, y);


        switch (opcion) {
            case 1:
                system("cls");

                nuevaInscripcion();

                rlutil::anykey();
                system("cls");
                break;
            case 2:
                system("cls");

                gestionarEstadoInscripcion();

                rlutil::anykey();
                system("cls");
                break;
            case 3:
                system("cls");

                menuListarInscripciones();

                system("cls");
                break;
        }

    } while (opcion != 0);
}





///MENU PRINCIPAL
void accionarMenu()
{
    int opcionMenu = -1, y = 0;
    system("cls");
    do
    {

        mostrarMenuGestion(opcionMenu, y);

        switch(opcionMenu)
        {
        case 1:
            menuClientes();
            break;
        case 2:
            menuActividades();
            break;
        case 3:
            menuInscripciones();
            system("cls");
            break;
        case 4:
            system("cls");
            cout << "Bob el constructor est� trabajando en esta opcion." << endl;
            rlutil::anykey();
            break;
        }
        if(opcionMenu != 0) opcionMenu = -1;
    }
    while(opcionMenu != 0);
    system("cls");
}
