#ifndef MENUINSCRIPCIONES_H_INCLUDED
#define MENUINSCRIPCIONES_H_INCLUDED

void listarInscripciones(int modoListado = 1);
void nuevaInscripcion();
void gestionarEstadoInscripcion();
void menuListarInscripciones();

#endif // MENUINSCRIPCIONES_H_INCLUDED
