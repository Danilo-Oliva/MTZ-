#ifndef MENUMODIFICARCLIENTE_H_INCLUDED
#define MENUMODIFICARCLIENTE_H_INCLUDED

int imprimirModificarCliente();
void menuModificarCliente();


#endif // MENUMODIFICARCLIENTE_H_INCLUDED
